# Kubernetes
<b>Deploying Kubernetes in AWS from Azure DevOPs<b>

----------------------------------------------------------------
|                         Tools                                 |
----------------------------------------------------------------
| <b>AWS + Azure DevOps + Docker + Terraform + Ansible + Git<b> |
----------------------------------------------------------------